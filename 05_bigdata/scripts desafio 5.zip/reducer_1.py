#!/usr/bin/python3.6

import sys

feed_mapper_output = sys.stdin
prev_tagid = None
tag_id_count = 0
sum_relevance = 0.0


for line_ocurrence in feed_mapper_output:
    tag_id, relevance = line_ocurrence\
                            .replace('\n', '')\
                            .split('\t')
    
    # Cambio de TAG: Calcular promedios
    if tag_id != prev_tagid:
        
        if prev_tagid is not None:
            print(f"{prev_tagid}\t{str(sum_relevance / tag_id_count)}")
        prev_tagid = tag_id
        tag_id_count = 0
        sum_relevance = 0
    
    # No hay cambios: Acumular
    tag_id_count += 1
    sum_relevance += float(relevance)

print(prev_tagid + '\t' + str(sum_relevance / tag_id_count))

